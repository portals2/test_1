let sceen;

function addListeners()
{
	screen = document.getElementById('screen');

	addDigitListener();
	addResetListener();
}

function addDigitListener()
{
	const btns = document.querySelectorAll('.digit');
	for(const btn of btns)
	{
		btn.addEventListener('click', () => {
				screen.value = screen.value + btn.textContent;
		});
	}
}

function addResetListener()
{
	const clearBtn = document.querySelector('.reset');
	clearBtn.addEventListener('click', function clear() {
		screen.value = "";
	});
}